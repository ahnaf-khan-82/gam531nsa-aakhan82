﻿using System;
using System.Collections.Generic;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using GL = OpenTK.Graphics.OpenGL4.GL;

namespace MidtermProject
{
    public sealed class Mesh : IDisposable
    {
        public int VAO { get; private set; }
        private int _vbo, _ebo;
        private int _indexCount;

        private Mesh(float[] interleaved, uint[] indices, int strideFloats)
        {
            _indexCount = indices.Length;

            VAO = GL.GenVertexArray();
            _vbo = GL.GenBuffer();
            _ebo = GL.GenBuffer();

            GL.BindVertexArray(VAO);

            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, interleaved.Length * sizeof(float), interleaved, BufferUsageHint.StaticDraw);

            GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ebo);
            GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * sizeof(uint), indices, BufferUsageHint.StaticDraw);

            int stride = strideFloats * sizeof(float);

            // layout(location=0) vec3 aPos
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, stride, 0);

            // layout(location=1) vec3 aNormal
            GL.EnableVertexAttribArray(1);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, stride, 3 * sizeof(float));

            // layout(location=2) vec2 aUV
            GL.EnableVertexAttribArray(2);
            GL.VertexAttribPointer(2, 2, VertexAttribPointerType.Float, false, stride, 6 * sizeof(float));

            GL.BindVertexArray(0);
        }

        public void Draw()
        {
            GL.BindVertexArray(VAO);
            GL.DrawElements(PrimitiveType.Triangles, _indexCount, DrawElementsType.UnsignedInt, 0);
        }

        public void Dispose()
        {
            if (VAO != 0) GL.DeleteVertexArray(VAO);
            if (_vbo != 0) GL.DeleteBuffer(_vbo);
            if (_ebo != 0) GL.DeleteBuffer(_ebo);
            VAO = _vbo = _ebo = 0;
        }

        // -------- UV Sphere (pole-safe UVs) --------
        public static Mesh CreateUvSphere(float radius, int lonSegments = 64, int latSegments = 32)
        {
            var verts = new List<float>();
            var inds = new List<uint>();

            for (int y = 0; y <= latSegments; y++)
            {
                float v = y / (float)latSegments;            // [0,1]
                float phi = MathHelper.Pi * v;               // [0,pi]
                float cosPhi = MathF.Cos(phi);
                float sinPhi = MathF.Sin(phi);

                for (int x = 0; x <= lonSegments; x++)
                {
                    float u = x / (float)lonSegments;        // [0,1]
                    float theta = MathHelper.TwoPi * u;       // [0,2pi]
                    float cosTheta = MathF.Cos(theta);
                    float sinTheta = MathF.Sin(theta);

                    // normals
                    float nx = sinPhi * cosTheta;
                    float ny = cosPhi;
                    float nz = sinPhi * sinTheta;

                    // position
                    float px = radius * nx;
                    float py = radius * ny;
                    float pz = radius * nz;

                    // FIX: keep UVs stable at the poles to avoid wrap/smear
                    if (y == 0 || y == latSegments) u = 0.5f;

                    // interleaved: pos(3) normal(3) uv(2)
                    verts.Add(px); verts.Add(py); verts.Add(pz);
                    verts.Add(nx); verts.Add(ny); verts.Add(nz);
                    verts.Add(u); verts.Add(v);             // use v directly (no 1 - v)
                }
            }

            uint stride = (uint)(lonSegments + 1);
            for (uint y = 0; y < latSegments; y++)
            {
                for (uint x = 0; x < lonSegments; x++)
                {
                    uint i0 = y * stride + x;
                    uint i1 = (y + 1) * stride + x;
                    uint i2 = (y + 1) * stride + (x + 1);
                    uint i3 = y * stride + (x + 1);

                    inds.Add(i0); inds.Add(i1); inds.Add(i2);
                    inds.Add(i0); inds.Add(i2); inds.Add(i3);
                }
            }

            return new Mesh(verts.ToArray(), inds.ToArray(), 8);
        }

        // -------- Inward Sky Cube (for equirectangular starfield) --------
        public static Mesh CreateSkyCube(float size = 60f)
        {
            float s = size;
            float[] v =
            {
                // pos                 normal         uv
                // +Z
                -s, -s,  s,           0,0,-1,        0,0,
                 s, -s,  s,           0,0,-1,        1,0,
                 s,  s,  s,           0,0,-1,        1,1,
                -s,  s,  s,           0,0,-1,        0,1,
                // -Z
                 s, -s, -s,           0,0, 1,        0,0,
                -s, -s, -s,           0,0, 1,        1,0,
                -s,  s, -s,           0,0, 1,        1,1,
                 s,  s, -s,           0,0, 1,        0,1,
                // -X
                -s, -s, -s,           1,0,0,         0,0,
                -s, -s,  s,           1,0,0,         1,0,
                -s,  s,  s,           1,0,0,         1,1,
                -s,  s, -s,           1,0,0,         0,1,
                // +X
                 s, -s,  s,          -1,0,0,         0,0,
                 s, -s, -s,          -1,0,0,         1,0,
                 s,  s, -s,          -1,0,0,         1,1,
                 s,  s,  s,          -1,0,0,         0,1,
                // -Y
                -s, -s, -s,           0,1,0,         0,0,
                 s, -s, -s,           0,1,0,         1,0,
                 s, -s,  s,           0,1,0,         1,1,
                -s, -s,  s,           0,1,0,         0,1,
                // +Y
                -s,  s,  s,           0,-1,0,        0,0,
                 s,  s,  s,           0,-1,0,        1,0,
                 s,  s, -s,           0,-1,0,        1,1,
                -s,  s, -s,           0,-1,0,        0,1,
            };

            uint[] idx =
            {
                0,1,2, 0,2,3,      4,5,6, 4,6,7,
                8,9,10, 8,10,11,   12,13,14, 12,14,15,
                16,17,18, 16,18,19, 20,21,22, 20,22,23
            };

            return new Mesh(v, idx, 8);
        }
    }
}
